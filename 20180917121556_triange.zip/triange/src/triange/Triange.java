 
package triange;

import java.util.Scanner;

 
public class Triange {

    
            int i;
        int j;
        
         public static void main(String[] args) {
        int rows;
        System.out.println("How many lines ?");
        Scanner ro= new Scanner(System.in);
                rows=ro.nextInt();

        for(int i = 1; i <= rows; ++i) {
            for(int j = 1; j <= i; ++j) {
                System.out.print("* ");
            }
            System.out.println();
        }
    }
}
